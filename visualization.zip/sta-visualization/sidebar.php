  <!-- BEGIN: Main Menu-->
  <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mr-auto"><a class="navbar-brand" href="../../../html/ltr/vertical-menu-template/index.html">
                        <div class="brand-logo"></div>
                        <h2 class="brand-text mb-0">P/L Analyzer</h2>
                    </a></li>
                </ul>
        </div>
        <div class="shadow-bottom"></div>
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                
                <li class=" navigation-header"><span>Sales Report</span>
                </li>
                <li class=" nav-item"><a href="sale-report-weekly.php"><i></i><span class="menu-title">Weekly</span></a>
                </li>
                <li class=" nav-item"><a href="sale-report-monthly.php"><i ></i><span class="menu-title">Monthly</span></a>
                </li>
                <li class=" nav-item"><a href="sale-report.php"><i></i><span class="menu-title" >Yearly</span></a>
                </li>
                 
                <li class=" navigation-header"><span>Inventory Report</span>
                </li>
                <li class=" nav-item"><a href="sale-report-weekly.php"><i></i><span class="menu-title">Weekly</span></a>
                </li>
                <li class=" nav-item"><a href="sale-report-monthly.php"><i ></i><span class="menu-title">Monthly</span></a>
                </li>
                <li class=" nav-item"><a href="sale-report.php"><i></i><span class="menu-title" >Yearly</span></a>
                </li>
               
                <li class=" navigation-header"><span>Traffic Summary Report</span>
                </li>
                <li class=" nav-item"><a href="sale-report-weekly.php"><i></i><span class="menu-title">Weekly</span></a>
                </li>
               
                <li class=" navigation-header"><span>Purchase Order Report</span>
                </li>
                <li class=" nav-item"><a href="sale-report-weekly.php"><i></i><span class="menu-title">Weekly</span></a>
                </li>
                <li class=" nav-item"><a href="sale-report-weekly.php"><i></i><span class="menu-title">Weekly Cumulative</span></a>
                </li>
                <li class=" nav-item"><a href="sale-report-weekly.php"><i></i><span class="menu-title">Monthly</span></a>
                </li>
                  
               
            </ul>
        </div>
    </div>
    <!-- END: Main Menu-->