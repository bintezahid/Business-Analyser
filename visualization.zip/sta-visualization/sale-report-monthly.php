<?php
include "header.php";
include "sidebar.php";
include "db.php";
?>


 <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-12 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-md-5">
                            <h2 class="content-header-title float-left mb-0">Monthly Sale Report <?php
							if(isset($_POST['month'])) {
							  echo htmlspecialchars($_POST['month']);
							  $month=htmlspecialchars($_POST['month']);
							  printf('<script>var month = '.$month.';</script>');
							}
							?> </h2>
                         								
                        </div>
						<div class="col-md-7">
                          
                         <form class="form-inline" action="sale-report-monthly.php" method=post style="float: right;">
							  <label for="email" class="mr-sm-2">Select Month:</label>
							 <fieldset class="form-group">
                                                    <select name=month class="form-control  mb-2 mr-sm-2" id="basicSelect">
                                                        <option value=1 >January</option>
                                                        <option value=2>February</option>
                                                        <option value=3>March</option>
														<option value=4>April</option>
														<option value=5>May</option>
														<option value=6>June</option>
														<option value=7>July</option>
														<option value=8>August</option>
                                                        <option value=9>September</option>
                                                        <option value=10>October </option>
                                                        <option value=11>November</option>
                                                        <option value=12>December</option>
                                                    </select>
                                                </fieldset>
							  <div class="form-check mb-2 mr-sm-2">
								
							  </div>
							  <button type="submit" class="btn btn-primary mb-2">Show Data</button>
							</form>
							

							
						
						
								
                        </div>
                    </div>
                </div>
               
            </div>
            <div class="content-body">
                
                <!-- apex charts section start -->
                <section id="apexchart">
			<div class="row">
				<div class="col-md-4" style="display:inline-block" > <!--Total Sales-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5"></i>
								</div>
                            </div>   
							<?php
										$sql = "SELECT if (sum(shipped_cogs)>0,sum(shipped_cogs),0) as totalsales FROM db_fyp.tbl_main_daily_sales s 
                                        inner join db_fyp.tbl_dim_date dm
                                        where s.fk_date_key=dm.date_key and month_of_year='$month'";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
											
											  // output data of each row
											  while($row = $result->fetch_assoc()) {
												  $cr_total_sales=$row["totalsales"];
												echo '<h2 class="text-bold-700 mt-1"> $ '.$row["totalsales"];
											  }
											  echo "</h2>";
											} else {
											  echo "0 results";
											}
										// $con->close();
											?>
									
							
							
					
							<p class="mb-0">Total Sale</p></br>
						</div>
					</div>
				</div>
				<div class="col-md-4" style="display:inline-block"> <!--Last Month Sales-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5"></i>
								</div>
							</div>
							<?php
										$sql = "Select if (sum(shipped_cogs)>0,sum(shipped_cogs),0) as LastMonthSales FROM db_fyp.tbl_main_daily_sales s 
																				inner join db_fyp.tbl_dim_date dm
																				where s.fk_date_key=dm.date_key and month_of_year='$month'-1";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
											
											  // output data of each row
											  while($row = $result->fetch_assoc()) {
												  $pr_total_sales=$row["LastMonthSales"];
												echo '<h2 class="text-bold-700 mt-1"> $ '.$row["LastMonthSales"];
											  }
											  echo "</h2>";
											} else {
											  echo "0 results";
											}
										// $con->close();
											?>
							<p class="mb-0">Last Month Sale</p></br>
						</div>
					</div>
				</div>
				<div class="col-md-4" style="display:inline-block"> <!-- MOM-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5"></i>
								</div>
							</div>
							<?php
										
								echo '<h2 class="text-bold-700 mt-1">';
								if($pr_total_sales!=0)
								echo ($cr_total_sales-$pr_total_sales)/$pr_total_sales*100;
										else echo '0';
								echo '%';
								echo "</h2>";
							?>
							</h2>
							<p class="mb-0">MoM Sales</p></br>
						</div>
					</div>
				</div>
			</div>	
			<!--	<div class="col-md-2">
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5"></i>
								</div>
							</div>
							<h2 class="text-bold-700 mt-1">92.6k</h2>
							<p class="mb-0">MOM</p></br>
						</div>
					</div>
				</div>
				<div class="col-md-2">
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5"></i>
								</div>
							</div>
							<h2 class="text-bold-700 mt-1">92.6k</h2>
							<p class="mb-0">WOW</p></br>
						</div>
					</div>
				</div> -->
				
				<div class="row">
				<div class="col-md-4" style="display:inline-block" > <!--Total Unit Sales-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5"></i>
								</div>
                            </div>
                           

                    
							<?php
										$sql = "SELECT if (sum(shipped_units)>0,sum(shipped_units),0) as totalunits FROM db_fyp.tbl_main_daily_sales s 
                                        inner join db_fyp.tbl_dim_date dm
                                        where s.fk_date_key=dm.date_key and month_of_year='$month'";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
											
											  // output data of each row
											  while($row = $result->fetch_assoc()) {
												  $cr_total_units=$row["totalunits"];
												echo '<h2 class="text-bold-700 mt-1">'.$row["totalunits"];
											  }
											  echo "</h2>";
											} else {
											  echo "0 results";
											}
										// $con->close();
											?>
									
							
							
					
							<p class="mb-0">Total Units Sold</p></br>
						</div>
					</div>
				</div>
				<div class="col-md-4" style="display:inline-block"> <!--Last Month Sales-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5"></i>
								</div>
							</div>
							<?php
										$sql = "Select if (sum(shipped_units)>0,sum(shipped_units),0) as lastunits FROM db_fyp.tbl_main_daily_sales s 
																				inner join db_fyp.tbl_dim_date dm
																				where s.fk_date_key=dm.date_key and month_of_year='$month'-1";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
											
											  // output data of each row
											  while($row = $result->fetch_assoc()) {
												  $pr_total_units=$row["lastunits"];
												echo '<h2 class="text-bold-700 mt-1"> '.$row["lastunits"];
											  }
											  echo "</h2>";
											} else {
											  echo "0 results";
											}
										// $con->close();
											?>
							<p class="mb-0">Last Month Sold Units</p></br>
						</div>
					</div>
				</div>
				<div class="col-md-4" style="display:inline-block"> <!-- MOM Units-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5"></i>
								</div>
							</div>
							<?php
										
								echo '<h2 class="text-bold-700 mt-1">';
								if($pr_total_units!=0)
								echo (($cr_total_units-$pr_total_units)/$pr_total_sales)*100;
										else echo '0';
								echo '%';
								echo "</h2>";
							?>
							</h2>
							<p class="mb-0">MoM Units</p></br>
						</div>
					</div>
				</div>
			</div>
				
                <div class="row">    <!-- Sale Graph-->
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title">Sale By Time</h4>
							</div>
							<div class="card-content">
								<div class="card-body">
									<div id="line-chart2"></div>
								</div>
							</div>
						</div>
					</div>
                </div>
				
				
				<div class="row">   
					<div class="col-md-6">   <!-- Top 5 Asins-->
					<div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Top 5 ASINS based on Shipped Cogs</h4>
                            </div>
                            <div class="card-content">
                               
                                <div class="table-responsive">
                                    	<?php
										$sql = "SELECT asin, product_title as product,sum(shipped_cogs) as sales 
										FROM db_fyp.tbl_main_daily_sales s inner join db_fyp.tbl_dim_date dm 
										where s.fk_date_key=dm.date_key and month_of_year='$month'
										group by asin
										order by sales desc Limit 5;";

										$result = $con->query($sql);
										if ($result->num_rows > 0) {
											echo '<table class="table table-striped mb-0"><thead>
                                            <tr>
                                                 <th scope="col">ASIN</th>
												<th scope="col">Product Name</th>
                                                <th scope="col">Total Sale</th>
                                               
                                            </tr>
                                        </thead><tbody>';
											  // output data of each row
											  while($row = $result->fetch_assoc()) {
												echo '<th scope="row">'.$row["asin"]."</th><td>".$row["product"]."</th><td>$".$row["sales"]."</td></tr>";
											  }
											  echo "</tbody>";
											} else {
											  echo "0 results";
											}
										// $con->close();
											?>
                                    </table>
                                </div>
                            </div>
                        </div>
					</div>

					<div class="col-md-6">  <!-- Lossable Products-->
					<div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Lossable Products According to Shipped Cogs</h4>
                            </div>
                            <div class="card-content">
                               
                                <div class="table-responsive">
								<?php
										$sql = "SELECT asin, product_title as product,sum(shipped_cogs) as sales FROM db_fyp.tbl_main_daily_sales s inner join db_fyp.tbl_dim_date dm 
										where s.fk_date_key=dm.date_key and month_of_year='$month'
										group by asin
										order by sales Asc Limit 5;";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
											echo '<table class="table table-striped mb-0"><thead>
                                            <tr>
                                                 <th scope="col">ID</th>
												<th scope="col">Product Name</th>
                                                <th scope="col">Sales</th>
                                               
                                            </tr>
                                        </thead><tbody>';
											  // output data of each row
											  while($row = $result->fetch_assoc()) {
												echo '<th scope="row">'.$row["asin"]."</th><td>".$row["product"]."</th><td>$".$row["sales"]."</td></tr>";
											  }
											  echo "</tbody>";
											} else {
											  echo "0 results";
											}
										// $con->close();
											?>
											
                                        </table>
                                </div>
                            </div>
                        </div>
					</div>
					
				</div>

			<!--	<div class="row">
					<div class="col-md-12">
					<div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Top 5 Tours According to Sale</h4>
                            </div>
                            <div class="card-content">
                               
                                <div class="table-responsive">
                                    
                                        
										</?php
										$sql = "select DISTINCT unique_tour_id,tour_name,tour_price from tbl_main_tours order by tour_price desc limit 5";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
											echo '<table class="table table-striped mb-0"><thead>
                                            <tr>
                                                 <th scope="col">ID</th>
												<th scope="col">Tour Name</th>
                                                <th scope="col">Sale</th>
                                               
                                            </tr>
                                        </thead><tbody>';
											  // output data of each row
											  while($row = $result->fetch_assoc()) {
												echo '<th scope="row">'.$row["unique_tour_id"]."</th><td>".$row["tour_name"]."</th><td>	".$row["tour_price"]."</td></tr>";
											  }
											  echo "</tbody>";
											} else {
											  echo "0 results";
											}
											$con->close();
											?>
											</table>
                                           
                                          
                                     
                                  
                                </div>
                            </div>
                        </div>
					</div>
				</div-->

                       
                    </div>
                </section>
                <!-- // Apex charts section end -->

            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>


<?php
include "footer.php";

?>