<?php
include "db.php";						
if($_POST){
	$data = array();
	$sql = "SELECT week as MonthName, sum(shipped_cogs) as Sales
	FROM db_fyp.tbl_main_daily_sales s 
	inner join db_fyp.tbl_dim_date dm
    where s.fk_date_key=dm.date_key group by month_name ASC";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
										
											//$data = $result->fetch_array();
											  // output data of each row
											  while($row = $result->fetch_assoc()) {
													$data['sales_data'][] = $row["Sales"];
													$data['sales_month'][]= $row["MonthName"];
											  }
											 
											} else {
											  $data['sales_data'][] = array(0,0,0,0);
											}
										// $con->close();
	
echo json_encode($data);
}
?>