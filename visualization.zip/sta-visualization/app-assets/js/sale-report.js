$(document).ready(function() {
var $primary = '#7367F0',
    $success = '#28C76F',
    $danger = '#EA5455',
    $warning = '#FF9F43',
    $info = '#00cfe8',
    $label_color_light = '#dae1e7';
var themeColors = [$primary, $success, $danger, $warning, $info];
  var yaxis_opposite = false;
  if($('html').data('textdirection') == 'rtl'){
    yaxis_opposite = true;
  }
	$.ajax({
			url: 'fetch_data_sale_report.php',
			type: 'post',
			data: {"monthname": monthname},
			dataType: 'json',
			error: function(xhr, status, error){
						var err = xhr.status;
						console.log(xhr.responseText);
						console.log(err + status + error);
						},
			success:function(response) 
			{
				console.log(response.sales);
				// Line Chart
  // ----------------------------------
  var lineChartOptions = {
    chart: {
      height: 350,
      type: 'line',
      zoom: {
        enabled: false
      }
    },
    colors: themeColors,
    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: 'straight'
    },
    series: [{
      name: "Sales",
      data: response.sales_data, 
    }],
    title: {
      text: 'Product Trends by Month',
      align: 'left'
    },
    grid: {
      row: {
        colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
        opacity: 0.5
      },
    },
    xaxis: {
      categories: response.sales_month,
    },
    yaxis: {
      tickAmount: 5,
      opposite: yaxis_opposite
    }
  }
  var lineChart = new ApexCharts(
    document.querySelector("#line-chart2"),
    lineChartOptions
  );
 lineChart.render();

  // Line Area Chart	
			}
	});


	
});