<?php
include "db.php";						
if($_POST){
	$data = array();
	// $sql = "SELECT category as category, sum(shipped_cogs) as sales
	// FROM db_fyp.tbl_main_daily_sales s 
	// inner join db_fyp.tbl_dim_date dm
	// where s.fk_date_key=dm.date_key group by category ASC";
	
	$year = $_POST['year'] ? $_POST['year'] : '';	
	$sql = "SELECT month_of_year as month_number, sum(shipped_cogs) as sales 
			FROM tbl_dim_date inner join tbl_main_daily_sales 
			WHERE tbl_dim_date.date_key=tbl_main_daily_sales.fk_date_key AND tbl_dim_date.calendar_year = '$year'
			group by month_of_year";
	$result = $con->query($sql);
	if ($result->num_rows > 0) {
	
		//$data = $result->fetch_array();
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$data['sales_data'][] = $row["sales"];
			$data['sales_month'][]= $row["month_number"];
		}
		echo json_encode($data);
	} else {
		echo json_encode('No Sales!');
	}
	// $con->close();
}
?>