<?php
include "header.php";
include "sidebar.php";
include "db.php";
?>

<?php
$year_field = 'calendar_year';
?>

 <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-12 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-md-5">
                            <h2 class="content-header-title float-left mb-0">Purchase Order Report <?php
							if(isset($_POST['year']) && isset($_POST['month']) && isset($_POST['week'])) {
							 // echo htmlspecialchars($_POST['month']);
							  $year=htmlspecialchars($_POST['year']);
                              $month=htmlspecialchars($_POST['month']);
                              $week=htmlspecialchars($_POST['week']); 
							 printf('<script> var year = '.$year.'; week = '.$week.'; var month = '.$month.'; </script>');
							}
							?> </h2>
                         								
                        </div>
						<div class="col-md-7">
                          
							<form class="form-inline" action="po-report-weekly.php" method=post style="float: right;">
								
							<!-- Add a year field start -->
								<fieldset class="form-group">
									<select name=year class="form-control  mb-2 mr-sm-2" id="basicSelect" required>
										<option value="">Select Year</option>
									<?php
										$sql = "SELECT DISTINCT ".$year_field." FROM tbl_dim_date ORDER BY ".$year_field." ASC";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {											
											// output data of each row
											while($row = $result->fetch_assoc()) {
									?>
												<option value="<?php echo $row[$year_field]; ?>" <?php if (isset($_POST['year']) && $_POST['year']==$row[$year_field]) echo "selected"; ?>><?php echo $row[$year_field]; ?></option>
									<?php
											}											
										} 							
									?>
									</select>
								</fieldset>
							<!-- Add a year field end --->	

								<fieldset class="form-group">
									<select name=month class="form-control  mb-2 mr-sm-2" id="basicSelect" required>
										<option value="">Select Month</option>
										<option value=1 <?php if (isset($_POST['month']) && $_POST['month']=='1') echo "selected"; ?>>January</option>
										<option value=2 <?php if (isset($_POST['month']) && $_POST['month']=='2') echo "selected"; ?>>February</option>
										<option value=3 <?php if (isset($_POST['month']) && $_POST['month']=='3') echo "selected"; ?>>March</option>
										<option value=4 <?php if (isset($_POST['month']) && $_POST['month']=='4') echo "selected"; ?>>April</option>
										<option value=5 <?php if (isset($_POST['month']) && $_POST['month']=='5') echo "selected"; ?>>May</option>
										<option value=6 <?php if (isset($_POST['month']) && $_POST['month']=='6') echo "selected"; ?>>June</option>
										<option value=7 <?php if (isset($_POST['month']) && $_POST['month']=='7') echo "selected"; ?>>July</option>
										<option value=8 <?php if (isset($_POST['month']) && $_POST['month']=='8') echo "selected"; ?>>August</option>
										<option value=9 <?php if (isset($_POST['month']) && $_POST['month']=='9') echo "selected"; ?>>September</option>
										<option value=10 <?php if (isset($_POST['month']) && $_POST['month']=='10') echo "selected"; ?>>October </option>
										<option value=11 <?php if (isset($_POST['month']) && $_POST['month']=='11') echo "selected"; ?>>November</option>
										<option value=12 <?php if (isset($_POST['month']) && $_POST['month']=='12') echo "selected"; ?>>December</option>
									</select>
								</fieldset>
                                <fieldset class="form-group">
									<select name=week class="form-control  mb-2 mr-sm-2" id="basicSelect" required>
										<option value="">Select Week</option>
										<option value=1 <?php if (isset($_POST['week']) && $_POST['week']=='1') echo "selected"; ?>>1</option>
										<option value=2 <?php if (isset($_POST['week']) && $_POST['week']=='2') echo "selected"; ?>>2</option>
										<option value=3 <?php if (isset($_POST['week']) && $_POST['week']=='3') echo "selected"; ?>>3</option>
										<option value=4 <?php if (isset($_POST['week']) && $_POST['week']=='4') echo "selected"; ?>>4</option>
									</select>
								</fieldset>  
								<div class="form-check mb-2 mr-sm-2">
								<div class="form-check mb-2 mr-sm-2">
									
								</div>
								<button type="submit" class="btn  mb-2" style="background:#32525b; color:#fff; ">Show Data</button>
							</form>					
								
                        </div>
                    </div>
                </div>               
            </div>

            <div class="content-body">
                
                <!-- apex charts section start -->
                <section id="apexchart">
			<div class="row">
                				<div class="col-md-4" style="display:inline-block" > <!--No of Purchase Orders-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5 total_sale_icon"></i>
								</div>
                            </div>   
							<?php
								if(isset($_POST['year']) && isset($_POST['month']) && isset($_POST['week'])) {
									$sql = "SELECT count(*) as numpo FROM tbl_tanabi_main_purchaseorders po inner join tbl_dim_date dm 
                                    where po.fk_date_dim_id=dm.date_key and month_of_year='$month' and week_of_month='$week' AND ".$year_field."='$year'";
									$result = $con->query($sql);
									if ($result->num_rows > 0) {
										
										// output data of each row
										while($row = $result->fetch_assoc()) {
											echo '<h2 class="text-bold-700 mt-1">'.number_format($row["numpo"],0,".",",");
										}
										echo "</h2>";
									} else {
										echo "0 results";
									}
								}else{
									echo "0 results";
								}
								// $con->close();
							?>					
					
							<p class="mb-0">No. of Purchase Order</p></br>
						</div>
					</div>
                </div>
                <div class="col-md-4" style="display:inline-block"> <!--Total PO-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5 last_sold_icon"></i>
								</div>
							</div>
							<?php
								if(isset($_POST['year']) && isset($_POST['month']) && isset($_POST['week'])) {
									$sql = "SELECT sum(total_po_cost) as totalcost FROM tbl_tanabi_main_purchaseorders po inner join tbl_dim_date dm 
                                    where po.fk_date_dim_id=dm.date_key and month_of_year='$month' and week_of_month='$week'-1 AND ".$year_field."='$year'";
									$result = $con->query($sql);
									if ($result->num_rows > 0) {
										
										// output data of each row
										while($row = $result->fetch_assoc()) {
											$totalcost=$row["totalcost"];
										echo '<h2 class="text-bold-700 mt-1">$ '.number_format($row["totalcost"], 2, ".", ",");
										}
										echo "</h2>";
									} else {
										echo "0 results";
									}
								}else{
									echo "0 results";
								}
								// $con->close();
							?>
							<p class="mb-0">Total Cost</p></br>
						</div>
					</div>
				</div>
				<div class="col-md-4" style="display:inline-block" > <!--Accepted Orders-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5 total_sale_icon"></i>
								</div>
                            </div>   
							<?php
								if(isset($_POST['year']) && isset($_POST['month']) && isset($_POST['week'])) {
									$sql = "SELECT sum(accepted_cost) as totalacceptedcost FROM tbl_tanabi_main_purchaseorders po inner join tbl_dim_date dm 
                                    where po.fk_date_dim_id=dm.date_key and month_of_year='$month' and week_of_month='$week' AND ".$year_field."='$year'";
									$result = $con->query($sql);
									if ($result->num_rows > 0) {
										
										// output data of each row
										while($row = $result->fetch_assoc()) {
											$acost = $row["totalacceptedcost"];
										echo '<h2 class="text-bold-700 mt-1"> $ '.number_format($row["totalacceptedcost"],2,".",",");
										}
										echo "</h2>";
									} else {
										echo "0 results";
									}
								}else{
									echo "0 results";
								}
								// $con->close();
							?>					
					
							<p class="mb-0">Total Accepted</p></br>
						</div>
					</div>
				</div>
				<div class="col-md-4" style="display:inline-block"> <!--Total Rejected cost-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5 last_sale_icon"></i>
								</div>
							</div>
							<?php
								if(isset($_POST['year']) && isset($_POST['month']) && isset($_POST['week'])) {
									$sql = "SELECT sum(rejected_cost) as rcost FROM tbl_tanabi_main_purchaseorders po inner join tbl_dim_date dm 
                                    where po.fk_date_dim_id=dm.date_key and month_of_year='$month' and week_of_month='$week' AND ".$year_field."='$year'";
									$result = $con->query($sql);
									if ($result->num_rows > 0) {
										
										// output data of each row
										while($row = $result->fetch_assoc()) {
											$rcost= $row["rcost"];
										echo '<h2 class="text-bold-700 mt-1"> $ '.number_format($row["rcost"],2,".",",");
										}
										echo "</h2>";
									} else {
										echo "0 results";
									}
								}else{
									echo "0 results";
								}
									// $con->close();
							?>
							<p class="mb-0">Total Rejected Cost</p></br>
						</div>
					</div>
				</div>
				<div class="col-md-4" style="display:inline-block"> <!-- Confirmation-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5"></i>
								</div>
							</div>
							<?php
										
							
								if(isset($_POST['year']) && isset($_POST['month']) && isset($_POST['week'])) {
									echo '<h2 class="text-bold-700 mt-1">';
									if($totalcost!=0){
									echo number_format(($acost/$totalcost)*100, 2, ".", ",");
									}
										else echo '0.00';
								echo '%';
								echo "</h2>"; 
								} 
							else {echo "0 results";}
								
							?>
							</h2>
							<p class="mb-0">Confirmation Rate</p></br>
						</div>
					</div>
				</div>
			</div>	
	
				
				
                <div class="row">   <!-- PO Graph-->
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title">Weekly Purchase Order Confirmation Rate</h4>
							</div>
							<div class="card-content">
								<div class="card-body">
									<div id="po-chart"></div>
								</div>
							</div>
						</div>
					</div>
                </div>
				
				
				<div class="row">
					<div class="col-md-6">  <!--Top 10 Based on Accepted Cost-->
					<div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Top 10 Based on Accepted Cost</h4>
                            </div>
                            <div class="card-content">
                               
                                <div class="table-responsive">
                                    	<?php
										if(isset($_POST['year']) && isset($_POST['month']) && isset($_POST['week'])) {
											$sql = "SELECT asin, title, accepted_cost FROM tbl_tanabi_main_purchaseorders po inner join tbl_dim_date dm 
                                            where po.fk_date_dim_id=dm.date_key and month_of_year='$month' and week_of_month='$week' AND ".$year_field."='$year' 
											order by accepted_cost Desc limit 10;";

											$result = $con->query($sql);
											if ($result->num_rows > 0) {
												echo '<table class="table table-striped mb-0"><thead>
												<tr>
													<th scope="col">ASIN</th>
													<th scope="col">Product Name</th>
													<th scope="col">Accepted Cost</th>
												
												</tr>
											</thead><tbody>';
												// output data of each row
												while($row = $result->fetch_assoc()) {
													echo '<th scope="row">'.$row["asin"]."</th><td>".$row["title"]."</th><td>	".$row["accepted_cost"]."</td></tr>";
												}
												echo "</tbody>";
												} else {
													echo "<p style='margin-left:20px;'>0 results</p>";
												}
										}else{
											echo "<p style='margin-left:20px;'>0 results</p>";
										}
											// $con->close();
												?>
                                    </table>
                                </div>
                            </div>
                        </div>
					</div>
					<div class="col-md-6"> <!--Top 10 Based on Rejected Cost-->
					<div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Top 10 Based on Rejected Cost</h4>
                            </div>
                            <div class="card-content">
                               
                                <div class="table-responsive">
								<?php
									if(isset($_POST['year']) && isset($_POST['month']) && isset($_POST['week'])) {
										$sql = "SELECT asin, title, rejected_cost FROM tbl_tanabi_main_purchaseorders po inner join tbl_dim_date dm 
                                        where po.fk_date_dim_id=dm.date_key and month_of_year='$month'and week_of_month='$week' AND ".$year_field."='$year' 
										order by rejected_cost Desc limit 10;";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
											echo '<table class="table table-striped mb-0"><thead>
                                            <tr>
                                                 <th scope="col">ASIN</th>
												<th scope="col">Product Name</th>
                                                <th scope="col">Rejected Cost</th>
                                               
                                            </tr>
                                        </thead><tbody>';
											  // output data of each row
											  while($row = $result->fetch_assoc()) {
												echo '<th scope="row">'.$row["asin"]."</th><td>".$row["title"]."</th><td>	".$row["rejected_cost"]."</td></tr>";
											  }
											  echo "</tbody>";
											} else {
											  echo "<p style='margin-left:20px;'>0 results</p>";
											}
									}else{
										echo "<p style='margin-left:20px;'>0 results</p>";
									}
										// $con->close();
								?>
											
                                        </table>
                                </div>
                            </div>
                        </div>
					</div>
					
				</div>


                       
                    </div>
                </section>
                <!-- // Apex charts section end -->

            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>


<?php
include "footer.php";

?>