<?php
include "header.php";
include "sidebar.php";
include "db.php";
?>
 <!-- BEGIN: Content-->
 <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0">Vendor Infomation</h2><br>
                        </div>    
                     <div class="col-md-4" style="display:inline-block" >
                        <?php
                            $sql = "SELECT concat(first_name, last_name) as vendorname FROM tbl_powerbi_roles p where p.user_id=136;";
							$result = $con-> query($sql);
									if ($result->num_rows > 0) {
										// output data of each row
										while($row = $result->fetch_assoc()) {
                                        echo '<p class="mb-0"> Name: '.$row["vendorname"].'<br>' ;
										}
										echo '</p>';
									} else {
										echo "0 results";
                                    }
                            ?>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>   

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<?php
include "footer.php";
?>