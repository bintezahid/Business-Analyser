<?php
include "db.php";						
if($_POST){
	$data = array();
	// $sql = "SELECT week as MonthName, sum(shipped_cogs) as Sales
	// FROM db_fyp.tbl_main_daily_sales s 
	// inner join db_fyp.tbl_dim_date dm
	// where s.fk_date_key=dm.date_key group by month_name ASC";
	
	$year = $_POST['year'] ? $_POST['year'] : '';
	
	$sql = "SELECT  sum(sellable_on_hand_units) as sinu, month_of_year as mon
            FROM tbl_dim_date inner join tbl_main_daily_inventory
            WHERE tbl_dim_date.date_key=tbl_main_daily_inventory.fk_date_key 
            AND tbl_dim_date.calendar_year = '$year' 
			group by mon;";
	$result = $con->query($sql);
	if ($result->num_rows > 0) {
	
		//$data = $result->fetch_array();
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$data['idata'][] = $row["sinu"];
			$data['iday'][]= $row["mon"];
		}
		echo json_encode($data);
	} else {
		// $data['sales_data'][] = array(0,0,0,0);
		echo json_encode('No Sellables!');
	}
	// $con->close();
}
?>