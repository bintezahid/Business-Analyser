  <!-- BEGIN: Main Menu-->
  <style>
   .navigation-header span{ 
      color:#fff;
  }
  .nav-item span{
    color:#fff;
  }
  </style>
  <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
        <div class="navbar-header" style="color:#fff; background:#32525b;">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mr-auto"><a class="navbar-brand" href="index.php">
                        <!---div class="brand-logo"  style="background-position: -120px -10px;"></div--->
                        <h2 class="brand-text mb-0" style="color:#fff;">P/L Analyzer</h2>
                    </a></li>
                </ul>
        </div>
        <!--div class="shadow-bottom"></div-->
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" style="color:#fff; background:#32525b;">
                
                <li class=" navigation-header"><span>Sales Report</span>
                </li>
                <li class=" nav-item"><a href="sale-report-weekly.php"><i></i><span class="menu-title">Weekly</span></a>
                </li>
                <li class=" nav-item"><a href="sale-report-monthly.php"><i ></i><span class="menu-title">Monthly</span></a>
                </li>
                <li class=" nav-item"><a href="sale-report-yearly.php"><i></i><span class="menu-title" >Yearly</span></a>
                </li>
                 
                <li class=" navigation-header"><span>Inventory Report</span>
                </li>
                <li class=" nav-item"><a href="inventory-report-weekly.php"><i></i><span class="menu-title">Weekly</span></a>
                </li>
                <li class=" nav-item"><a href="inventory-report-monthly.php"><i ></i><span class="menu-title">Monthly</span></a>
                </li>
                <li class=" nav-item"><a href="inventory-report-yearly.php"><i></i><span class="menu-title" >Yearly</span></a>
                </li>
               
                <li class=" navigation-header"><span>Traffic Summary Report</span>
                </li>
                <li class=" nav-item"><a href="traffic-report-weekly.php"><i></i><span class="menu-title">Weekly</span></a>
                </li>
               
                <li class=" navigation-header"><span>Purchase Order Report</span>
                </li>
                <li class=" nav-item"><a href="po-report-weekly.php"><i></i><span class="menu-title">Weekly</span></a>
                </li>

                <li class=" navigation-header"><span>Dropship Report</span>
                </li>
                <li class=" nav-item"><a href="dropship-report.php"><i></i><span class="menu-title">Dropships</span></a>
                </li>
              
                <li class=" navigation-header"><span>AMS Report</span>
                </li>
                <li class=" nav-item"><a href="campaign-report.php"><i></i><span class="menu-title">Monthly Campaign</span></a>
                </li>
                <li class=" nav-item"><a href="campaign-cat-report.php"><i></i><span class="menu-title">Campaign By Sales</span></a>
                </li>
            </ul>
        </div>
    </div>
    <!-- END: Main Menu-->