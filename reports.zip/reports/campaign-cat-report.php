<?php
include "header.php";
include "sidebar.php";
include "db.php";
?>

<?php
$year_field = 'calendar_year';
?>
 <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-12 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-md-5">
                            <h2 class="content-header-title float-left mb-0">Campaign by Category Report <?php
							if(isset($_POST['year'])) {
							//  echo htmlspecialchars($_POST['year']);
							  $year=htmlspecialchars($_POST['year']);							 
							printf('<script>var year = '.$year.';</script>');
							}
							?> </h2>
                         								
                        </div>
						<div class="col-md-7">
                          
                         <form class="form-inline" action="campaign-cat-report.php" method=post style="float: right;">
							<!-- Add a year field start --->
							<!-- <label for="year" class="mr-sm-2">Select Year:</label> -->
							<fieldset class="form-group">
									<select name=year class="form-control  mb-2 mr-sm-2" id="basicSelect" required>
										<option value="">Select Year</option>
									<?php
										$sql = "SELECT DISTINCT " . $year_field . " FROM tbl_dim_date ORDER BY ".$year_field." ASC";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {											
											// output data of each row
											while($row = $result->fetch_assoc()) {
									?>
												<option value="<?php echo $row[$year_field]; ?>" <?php if (isset($_POST['year']) && $_POST['year']==$row[$year_field]) echo "selected"; ?>><?php echo $row[$year_field]; ?></option>
									<?php
											}											
										} 							
									?>
									</select>
							</fieldset>
							<!-- Add a year field end  -->								
							  <div class="form-check mb-2 mr-sm-2">
								
							  </div>
							  <button type="submit" class="btn btn-success mb-2" onclick="display_yearly_report();" style="background-color:#32525b; color:#fff">Show Data</button>
							</form>			
								
                        </div>
                    </div>
                </div>
               
            </div>
            <div class="content-body">
                
                <!-- apex charts section start -->
    <section id="apexchart">
						
                <div class="row">    <!-- Campaign Graph-->
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title">Sale By Campaign Type</h4>
							</div>
							<div class="card-content">
								<div class="card-body">
									<div id="line-chart1"></div>
								</div>
							</div>
						</div>
					</div>
                </div>
				
				
			<div class="row">   
				<div class="col-md-12">   <!-- Top 10 Asins -->
					<div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Top 10 ASINS by Sponsored Product Campaigns</h4>
                            </div>
                            <div class="card-content">
                               
                                <div class="table-responsive">
                                <?php
									if(isset($_POST['year'])) {
										$sql = "SELECT  advertised_asin, impressions, clicks,  spend, total_sales, acos, roas 
										FROM tbl_main_monthly_ams_spproduct ac inner join db_fyp.tbl_dim_date dm
                                        where ac.fk_date_key=dm.date_key and ".$year_field."='$year'
										Order by roas desc Limit 10; ";

										$result = $con->query($sql);
										if ($result->num_rows > 0) {
											echo '<table class="table table-striped mb-0"><thead>
											<tr>
												<th scope="col">Advertised ASIN</th>
												<th scope="col">Impressions</th>
												<th scope="col">Clicks</th>
												<th scope="col">Spent</th>
												<th scope="col">Sale</th>
												<th scope="col">ACOS</th>
												<th scope="col">ROAS</th>
											
											</tr>
										</thead><tbody>';
											// output data of each row
											
											while($row = $result->fetch_assoc()) {
						
												echo '<th scope="row">'.$row["advertised_asin"].'</th><td>'.$row["impressions"].'</td><td>'.$row["clicks"].'</td><td>'.$row["spend"].'/td><td>'.$row["total_sales"].'</td><td>'.$row["acos"].'</td><td>'.$row["roas"].'</td></tr>';
											}
											echo "</tbody>";
									}else{
										echo "<p style='margin-left:20px;'>0 results</p>";
									}
										// $con->close();
								?>
                                    </table>
                                </div>
                            </div>
                        </div>
					</div>
				</div>
			<div class="col-md-6">  <!-- Lossable Products-->
					<div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Lossable Products According to Shipped Cogs</h4>
                            </div>
                        <div class="card-content">
                               
                            <div class="table-responsive">
								<?php
									if(isset($_POST['year'])) {
										$sql = "SELECT asin, product_title as product,sum(shipped_cogs) as sales FROM tbl_main_daily_sales s inner join tbl_dim_date dm 
										where s.fk_date_key=dm.date_key and ".$year_field."='$year'
										group by asin
										order by sales Asc Limit 5;";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
								       echo '<table class="table table-striped mb-0"><thead>
                                            <tr>
                                                 <th scope="col">ID</th>
												<th scope="col">Product Name</th>
                                                <th scope="col">Sales</th>
                                               
                                            </tr>
                                        </thead><tbody>';
											  // output data of each row
											  while($row = $result->fetch_assoc()) {
												echo '<th scope="row">'.$row["asin"]."</th><td>".$row["product"]."</th><td>$".$row["sales"]."</td></tr>";
											  }
											  echo "</tbody>";
											} else {
												echo "<p style='margin-left:20px;'>0 results</p>";
											}
									}else{
										echo "<p style='margin-left:20px;'>0 results</p>";
									}
									echo " </table>"	;
									// $con->close();
								?>
											
                            </div>     
                                
                        </div>
                    </div>
				</div>
					
			

                       
        	</div>
        </section>
                <!-- // Apex charts section end -->

            </div>
        </div>
</div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>


<?php
include "footer.php";
?>