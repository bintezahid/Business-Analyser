<?php
include "db.php";						
if($_POST){
	$data = array();
	// $sql = "SELECT week as MonthName, sum(shipped_cogs) as Sales
	// FROM db_fyp.tbl_main_daily_sales s 
	// inner join db_fyp.tbl_dim_date dm
	// where s.fk_date_key=dm.date_key group by month_name ASC";
	
	$year = $_POST['year'] ? $_POST['year'] : '';
	$month = $_POST['month'] ? $_POST['month'] : '';
	$week = $_POST['week'] ? $_POST['week'] : '';
	$sql = "SELECT day_of_week as day_number, sum(total_po_cost) as totalcost
            FROM tbl_dim_date dm inner join tbl_tanabi_main_purchaseorders po 
            WHERE dm.date_key=po.fk_date_dim_id AND tbl_dim_date.month_of_year = '$month' AND tbl_dim_date.calendar_year = '$year' 
			And tbl_dim_date.week_of_month='$week'	
			group by day_of_week";
	$result = $con->query($sql);
	if ($result->num_rows > 0) {
	
		//$data = $result->fetch_array();
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$data['sales_data'][] = $row["totalcost"];
			$data['sales_day'][]= $row["day_number"];
		}
		echo json_encode($data);
	} else {
		// $data['sales_data'][] = array(0,0,0,0);
		echo json_encode('No Cost!');
	}
	// $con->close();
}
?>