<?php
include "header.php";
include "sidebar.php";
include "db.php";
?>

<?php
$year_field = 'calendar_year';
?>

 <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-12 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-md-5">
                            <h2 class="content-header-title float-left mb-0">Yearly Inventory Report <?php
							if(isset($_POST['year'])) {
							 // echo htmlspecialchars($_POST['month']);
							  $year=htmlspecialchars($_POST['year']);
                              printf('<script> var year = '.$year.'; </script>');
							}
							?> </h2>
                         								
                        </div>
						<div class="col-md-7">
                          
							<form class="form-inline" action="inventory-report-yearly.php" method=post style="float: right;">
								
							<!-- Add a year field start -->
								<fieldset class="form-group">
									<select name=year class="form-control  mb-2 mr-sm-2" id="basicSelect" required>
										<option value="">Select Year</option>
									<?php
										$sql = "SELECT DISTINCT ".$year_field." FROM tbl_dim_date ORDER BY ".$year_field." ASC";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {											
											// output data of each row
											while($row = $result->fetch_assoc()) {
									?>
												<option value="<?php echo $row[$year_field]; ?>" <?php if (isset($_POST['year']) && $_POST['year']==$row[$year_field]) echo "selected"; ?>><?php echo $row[$year_field]; ?></option>
									<?php
											}											
										} 							
									?>
									</select>
								</fieldset>
							<!-- Add a year field end --->	

			
								 
								<div class="form-check mb-2 mr-sm-2">
									
								</div>
								<button type="submit" class="btn  mb-2" style="background:#32525b; color:#fff; ">Show Data</button>
							</form>					
								
                        </div>
                    </div>
                </div>               
            </div>

            <div class="content-body">
                
                <!-- apex charts section start -->
                <section id="apexchart">
			<div class="row">
				<div class="col-md-4" style="display:inline-block" > <!--Sellable Inventory-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5 total_sale_icon"></i>
								</div>
                            </div>   
							<?php
								if(isset($_POST['year'])) {
									$sql = "SELECT  sum(sellable_on_hand_inventory) as sinv
                                    FROM tbl_dim_date inner join tbl_main_daily_inventory
                                    WHERE tbl_dim_date.date_key=tbl_main_daily_inventory.fk_date_key 
									and  ".$year_field."='$year'";
									$result = $con->query($sql);
									if ($result->num_rows > 0) {
										
										// output data of each row
										while($row = $result->fetch_assoc()) {
											$cr_total_sales = $row["sinv"];
										echo '<h2 class="text-bold-700 mt-1"> $ '.number_format($row["sinv"],2,".",",");
										}
										echo "</h2>";
									} else {
										echo "0 results";
									}
								}else{
									echo "0 results";
								}
								// $con->close();
							?>					
					
							<p class="mb-0">Sellable On Hand Inventory</p></br>
						</div>
					</div>
				</div>
				<div class="col-md-4" style="display:inline-block"> <!--Sellable Units-->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5 last_sale_icon"></i>
								</div>
							</div>
							<?php
								if(isset($_POST['year'])) {
									$sql = "SELECT  sum(sellable_on_hand_units) as sinu
                                    FROM tbl_dim_date inner join tbl_main_daily_inventory
                                    WHERE tbl_dim_date.date_key=tbl_main_daily_inventory.fk_date_key and
                                     ".$year_field."='$year'";
									$result = $con->query($sql);
									if ($result->num_rows > 0) {
										
										// output data of each row
										while($row = $result->fetch_assoc()) {
											$pr_total_sales = $row["sinu"];
										echo '<h2 class="text-bold-700 mt-1"> '.number_format($row["sinu"],0,".",",");
										}
										echo "</h2>";
									} else {
										echo "0 results";
									}
								}else{
									echo "0 results";
								}
									// $con->close();
							?>
							<p class="mb-0">Sellable On Hand Units</p></br>
						</div>
					</div>
				</div>
				<div class="col-md-4" style="display:inline-block"> <!-- ACU -->
					<div class="card">
						<div class="card-header d-flex flex-column align-items-start pb-0">
							<div class="avatar bg-rgba-primary p-50 m-0">
								<div class="avatar-content">
									<i class="feather icon-users text-primary font-medium-5"></i>
								</div>
							</div>
							<?php
										
							
								if(isset($_POST['year'])) {
									echo '<h2 class="text-bold-700 mt-1">';
									if($pr_total_sales!=0){
									echo'$'.number_format(($cr_total_sales/$pr_total_sales), 2, ".", ",");
									}
										else echo '0.00';
								
								echo "</h2>"; 
								} 
							else {echo "0 results";}
								
							?>
							</h2>
							<p class="mb-0">ACU</p></br>
						</div>
					</div>
				</div>
			</div>	
			
				
                <div class="row">   <!-- Inventory Graph-->
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title">Inventory By Time</h4>
							</div>
							<div class="card-content">
								<div class="card-body">
									<div id="inv-chart"></div>
								</div>
							</div>
						</div>
					</div>
                </div>
				
				
			
                       
                    </div>
                </section>
                <!-- // Apex charts section end -->

            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>


<?php
include "footer.php";

?>