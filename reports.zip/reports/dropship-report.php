<?php
include "header.php";
include "sidebar.php";
include "db.php";
?>

<?php
$year_field = 'calendar_year';
?>
 <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-12 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-md-5">
                            <h2 class="content-header-title float-left mb-0">Dropship Report <?php
							if(isset($_POST['year'])) {
							//  echo htmlspecialchars($_POST['year']);
							  $year=htmlspecialchars($_POST['year']);							 
							printf('<script>var year = '.$year.';</script>');
							}
							?> </h2>
                         								
                        </div>
						<div class="col-md-7">
                          
                         <form class="form-inline" action="dropship-report.php" method=post style="float: right;">
							<!-- Add a year field start --->
							<!-- <label for="year" class="mr-sm-2">Select Year:</label> -->
							<fieldset class="form-group">
									<select name=year class="form-control  mb-2 mr-sm-2" id="basicSelect" required>
										<option value="">Select Year</option>
									<?php
										$sql = "SELECT DISTINCT " . $year_field . " FROM tbl_dim_date ORDER BY ".$year_field." ASC";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {											
											// output data of each row
											while($row = $result->fetch_assoc()) {
									?>
												<option value="<?php echo $row[$year_field]; ?>" <?php if (isset($_POST['year']) && $_POST['year']==$row[$year_field]) echo "selected"; ?>><?php echo $row[$year_field]; ?></option>
									<?php
											}											
										} 							
									?>
									</select>
							</fieldset>
							<!-- Add a year field end  -->								
							  <div class="form-check mb-2 mr-sm-2">
								
							  </div>
							  <button type="submit" class="btn btn-success mb-2" onclick="display_yearly_report();" style="background-color:#32525b; color:#fff">Show Data</button>
							</form>			
								
                        </div>
                    </div>
                </div>
               
            </div>
            <div class="content-body">
                
                <!-- apex charts section start -->
                <section id="apexchart">
		
                <div class="row">    <!-- Dropship Chart-->
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title">Dropships by Time</h4>
							</div>
							<div class="card-content">
								<div class="card-body">
									<div id="cat-chart"></div>
								</div>
							</div>
						</div>
					</div>
                </div>
				
				
				<div class="row">   
				 <div class="col-md-12">   <!-- Top 10 brands-->
					<div class="card">
                            <div class="card-header">
                                <h4 class="card-title" style="text-align: center;">Top 10 Dropships Based on Cost</h4>
                            </div>
                            <div class="card-content">
                               
                                <div class="table-responsive">
                                <?php
									if(isset($_POST['year'])) {
										$sql = "SELECT asin, order_id, item_quantity, total_cost, shipped_date 
                                        FROM tbl_main_tanabi_dropship ds inner join tbl_dim_date dm
                                        where ds.datekey=dm.date_key and calendar_year='$year'
										Order by total_cost desc Limit 10;";

										$result = $con->query($sql);
										if ($result->num_rows > 0) {
											echo '<table class="table table-striped mb-0"><thead>
                                            <tr>
                                                 <th scope="col"> ASIN</th>
												<th scope="col">Order ID</th>
												<th scope="col">Quantity</th>
												<th scope="col">Cost</th>
												<th scope="col">Shipped Date</th>
	                                        </tr>
                                        </thead><tbody>';
											  // output data of each row
											  while($row = $result->fetch_assoc()) {
												echo
												'<tr>
												<th scope="row">'.$row["asin"].'</th>
												<td>'.$row["order_id"].'</td>
												<td>'.$row["item_quantity"].'</td>
												<td>$'.$row["total_cost"].'</td>
												<td>'.$row["shipped_date"].'</td>
												</tr>';
												
											}
											  echo "</tbody>";
											} else {
												echo "<p style='margin-left:20px;'>0 results</p>";
											}
									}else{
										echo "<p style='margin-left:20px;'>0 results</p>";
									}
										// $con->close();
								?>
                                    </table>
                                </div>
                            </div>
                        </div>
				</div>
		
				 </div>                
                </div>
                </section>
                <!-- // Apex charts section end -->

            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>


<?php
include "footer.php";

?>